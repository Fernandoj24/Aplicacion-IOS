//
//  EventCell.swift
//  Evidencia_3
//
//  Created by Fer DLR on 20/05/2021
//

import UIKit

class EventCell: UITableViewCell
{
	@IBOutlet weak var eventLabel: UILabel!
}
