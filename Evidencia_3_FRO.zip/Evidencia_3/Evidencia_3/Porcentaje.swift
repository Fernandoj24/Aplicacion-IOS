//
//  Porcentaje.swift
//  Evidencia_3
//
//  Created by Fer DLR on 5/23/21.
//

import Foundation
import UIKit

class PorcentajeViewController: UIViewController
{
    
    @IBOutlet weak var dinero: UITextField!
    
    @IBAction func Bcalcular(_ sender: Any) {
        
        let x = Float (dinero.text!)
        let y = Float (x! * 0.10)
        
        total.text = "\(y)"
    }
    
    @IBOutlet weak var total: UILabel!
    
    
        
    
}




