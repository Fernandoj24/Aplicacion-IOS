//
//  Porcentaje1.swift
//  Evidencia_3
//
//  Created by user182891 on 5/23/21.
//

import SwiftUI

struct Porcentaje1: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Porcentaje1_Previews: PreviewProvider {
    static var previews: some View {
        Porcentaje1()
    }
}
