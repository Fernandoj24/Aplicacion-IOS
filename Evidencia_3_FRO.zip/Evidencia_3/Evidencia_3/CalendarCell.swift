//
//  CalendarCell.swift
//  Evidencia_3
//
//  Created by Fer DLR on 16/05/2021
//

import UIKit

class CalendarCell: UICollectionViewCell
{
	@IBOutlet weak var dayOfMonth: UILabel!
}
