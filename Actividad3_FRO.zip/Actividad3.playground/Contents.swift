import UIKit

var numeroE=4
let numeroE2:Int = 5

var numeroF=1.5
let numeroF2:Float = 2.0

var String1 = "hola"
let Strin2: String = "mundo"

//Asociacion


var Asociacion1 = ("IOS",15)
print("La asociacion 1 es \(Asociacion1)")





//ArraList

var Numeros:Array<Int> = Array<Int>()
Numeros.append(1)
Numeros.append(2)
Numeros.append(3)
Numeros.append(4)
Numeros.append(5)
Numeros.append(6)
Numeros.append(7)
Numeros.append(8)
Numeros.append(9)
Numeros.append(10)

//Dictionary

var dire:Dictionary<Int,String> = Dictionary<Int,String>()
dire=[1:"Lunes"]
dire=[2:"Martes"]
dire=[3:"Miercoles"]
dire=[4:"Jueves"]
dire=[5:"Viernes"]


