 import UIKit



// Valor Tipo Referencia
var costo_referencia = [8,3,10,5,9,9]
var impuesto = [Double]()
 var indice: Int = 0


 while(indice<costo_referencia.count){
    impuesto.append(Double (costo_referencia[indice]) * (0.84))
    indice = indice + 1
    
 }

impuesto

 let tres = {(n3:Int) -> Int in return n3}
 func porTres(n1:Int,n2:Int,n3:Int)->Int{
    
    
    return (n1+n2+n3)
    
 }
 var x3 = porTres(n1: 15, n2: 15,n3:tres(4))
 
print(x3)

 
 //Funciones Personalizadas y genericos
 
 func Cambio(x:Int,y:Int)->(Int,Int){
    var yx = y
    var xy = x
    xy = y
    yx = x
    
    return (xy,yx)
    
 }

 Cambio (x: 15, y: 78)

 var datos = [3,7,9,2]
 

 //Librerias
 var precios = [4.2,5.3,8.2,4.5]
 
 var impuestoo = precios.map{a in return a * 0.84}
print (impuestoo)
 
 var precio_menor = impuestoo.filter{a in a>6.0}
print (precio_menor)
 
