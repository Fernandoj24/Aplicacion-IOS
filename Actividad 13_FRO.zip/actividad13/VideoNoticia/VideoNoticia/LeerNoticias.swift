//
//  LeerNoticias.swift
//  VideoNoticia
//
//  Created by alicharlie on 12/05/16.
//  Copyright © 2016 codepix. All rights reserved.
//

import Foundation


class LeerNoticias{


    func getNoticias(_: (_ datos:[String])->()){
      
    }

    var url = URL(string: "http://api.nytimes.com/svc/mostpopular/v2/mostviewed/arts/30.json?api-key=029bb2ef5c76452bac5b2c3ca06893dd")


    let req = NSMutableURLRequest(url:url)
    let config = URLSessionConfiguration.default
    
    
}
