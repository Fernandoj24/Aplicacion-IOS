import UIKit


//Operadores

infix operator +* //Numero +* Potencia
var res = 1
 func +*(valor:Int,pow:Int)->(Int)
{
    
    
    
    for  _ in 1...pow{
        
        res=res*valor
    }
    
    
    return res
    
}

prefix operator |>
var numeros = [2,5,3,4]

prefix func |>(array:Int){
    
    numeros.sort()
    
    print (numeros)
    
}



8+*4
|>1

//SubsScript

var cantidades = [2,3,4,5]
var cantidadF = [Int]()
let count = cantidades.count
var i = 0

struct Cantidad
{
 
    let multiplier:Int
    subscript (idx:Int)->Int
    {
        
        get{
        return cantidades[idx]
        }
        
        set (nuevo) {
        
            while i < (count){
                
                cantidadF.append(cantidades[i] * 2)
                i = i+1
            }
        
        }
    }
}

//SubScript 1
var cn = Cantidad(multiplier: 3)
cn[1] = 2
print (cantidadF)
cantidadF[2]
cn[2]

//Subscript 2

var x:Double = 0
var y:Double = 0

struct CGPoint
{
    
    subscript(Px:Double,Py:Double) -> (Double,Double)
    {
        
        get{
            return (x,y)
        }
        
        set(pos){
            x = Px
            y = Py
            
            print("La nueva posicion es: X=",x," Y=",y)
        }
    }
    
}

var CG = CGPoint()

CG[60,30] = (0.0,0.0)//Nueva Posicion
CG[0.0,0.0]// Ver posicion

//Control de Errores

let dictError = ["A":1,"B":2,"C":3]

func Existe(idx:String)
{
    guard let existe = dictError[idx] else{
        
        print("No existe")
        return
    }
    print ("Si existe y es:",existe)
}

Existe (idx: "B")
dictError["A"]
