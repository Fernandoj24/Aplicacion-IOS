//
//  CalenC.swift
//  Proyecto
//
//  Created by Ochoa Rosa on 16/04/21.
//  Copyright © 2021 Ochoa Rosa. All rights reserved.
//

import Foundation
import UIKit

class CalenC : UICollectionViewCell{
    
    
    @IBOutlet weak var dayOfMonth:UILabel!
    
    
}
