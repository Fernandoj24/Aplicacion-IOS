//
//  Calenhelp.swift
//  Proyecto
//
//  Created by Ochoa Rosa on 16/04/21.
//  Copyright © 2021 Ochoa Rosa. All rights reserved.
//

import Foundation
import UIKit


class Calenhelp{
    
    let calendar = Calendar.current
 
    func masMes(date : Date)-> Date{
        
        return calendar.date(bySetting: .month, value: 1,of:date)!
    }
    
    
    func menosMes(date : Date)-> Date{
        
        return calendar.date(bySetting: .month, value: -1,of:date)!
    }
    
    
    func mesString(date: Date)->String
    {
    
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "LLLL"
        return dateFormatter.string(from: date)
    
    }
    
    
    
    func añoString(date: Date)->String
    {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy"
        return dateFormatter.string(from: date)
        
    }
    
    
    func daysInMonth(date:Date)->Int
    {
        
        
        let range = calendar.range(of:.day,in:.month,for:date)!
        return range.count
    }
    
    
    
    func dayofMoth(date:Date)->Int
    {
        
        
        let components = calendar.dateComponents([.day],from:date)
        return components.day!
    }
    
    
    func firstofMonth(date:Date)->Date
    {
        
        
        let components = calendar.dateComponents([.year, .month],from:date)
        return calendar.date(from:components)!
    }
    
    
    func weekDay(date:Date)->Int
    {
        
        
        let components = calendar.dateComponents([.weekday],from:date)
        return components.weekday! - 1
    }
}
