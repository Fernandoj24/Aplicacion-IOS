//
//  ViewController.swift
//  Proyecto
//
//  Created by Ochoa Rosa on 15/04/21.
//  Copyright © 2021 Ochoa Rosa. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    

    @IBOutlet weak var mesLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var selectedDate = Date()
    var tsqu = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setCellsView()
        setMesView()
        // Do any additional setup after loading the view.
    }
    
    func setCellsView(){
        
        let width = (collectionView.frame.size.width-2) / 8
        let height = (collectionView.frame.size.height-2) / 8
        
        let flowLayout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        flowLayout.itemSize = CGSize(width:width,height:height)
    }
    
    
    func setMesView()
    {
        
        tsqu.removeAll()
        let daysInMonth = Calenhelp().daysInMonth(date:selectedDate)
        let primerDiaMes = Calenhelp().firstofMonth(date: selectedDate)
        let startingSpaces = Calenhelp().weekDay(date:primerDiaMes)
        
        var count : Int = 1
        
        while(count<=42)
        {
            
            if(count <= startingSpaces || count - startingSpaces > daysInMonth)
            {
                
                tsqu.append("")
            }
            else
            {
                
                tsqu.append(String(count - startingSpaces))
            }
            
            count += 1
        }
        
        mesLabel.text =  Calenhelp().mesString(date: selectedDate)
        + " " + Calenhelp().añoString(date: selectedDate)
        
        collectionView.reloadData()
    }
    
    
    @IBAction func prevM(_ sender: Any)
    {
        selectedDate = Calenhelp().menosMes(date: selectedDate)
        setMesView()
        
    }
    
    @IBAction func nextM(_ sender: Any)
    {
        selectedDate = Calenhelp().masMes(date: selectedDate)
        setMesView()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        tsqu.count
        return 0
    }
    
    override open var shouldAutorotate: Bool
    {
        
        return false
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "calCell", for: indexPath )as! CalenC
        
        cell.dayOfMonth.text = tsqu[indexPath.item]
        
        return cell
    }
    
}

