import UIKit

var datos=[3,6,9,2,4,1];

for i in datos {
    
    if(i<5){
        print(i)
    }
    
}


func suma(n1:Int,n2:Int)->Int{
    
    return n1+n2;
}
func potencia(b:Int,p:Int)->Int{
   var total=1
   var i=0
    while i<=p{
        
        total=total*b
        i+=1
    }
    return total
}

enum meses{
    case Enero
    case Febrero
    case Marzo
    case Abril
    case Mayo
    case Junio
    case Julio
    case Agosto
    case Septiembre
    case Octubre
    case Noviembre
    case Diciembre
}
var NumeroMes:meses
NumeroMes = .Diciembre
switch NumeroMes{
    
case .Enero:
    print("1")
case .Febrero:
    print("2")
case .Marzo:
    print("3")
case .Abril:
    print("4")
case .Mayo:
    print("5")
case .Junio:
    print("6")
case .Julio:
    print("7")
case .Agosto:
    print("8")
case .Septiembre:
    print("9")
case .Octubre:
    print("10")
case .Noviembre:
    print("11")
case .Diciembre:
    print("13")
}
    


suma(n1:5,n2:5)
potencia(b:2,p:5)
