import UIKit

//Clases y Metoodos
class Persona{
    
    var nombre = ""
    
    func Saludar(nombre:String)
    {
        
        print (nombre,", mucho gusto")
        
    }
    func Caminar(pasos:Int)
    {
        let pasoS=String(pasos)
        print ("Los pasos que se dieron fueron:",pasoS)
    }
    
    
}

var p1=Persona()
p1.Saludar(nombre:"Fernando")
p1.Caminar(pasos: 30)

//Struct

struct Pantalla
{
    var ancho:Int
    var alto:Int
    
    init(alto:Int,ancho:Int){
        
        self.alto = alto
        self.ancho = ancho
    }
}

var str = Pantalla(alto:50,ancho:50)

//Extension

extension Int{
    
    func horas()->Int{
        return self*60*60
    }
}
extension String{
    
    var dia:String{
        if(self=="Lunes"){
            return "2"
        }
        if(self=="Martes"){
            return "3"
        }
        if(self=="Miercoles"){
            return "4"
        }
        if(self=="Jueves"){
            return "5"
        }
        if(self=="Viernes"){
            return "6"
        }
        if(self=="Sabado"){
            return "7"
        }
        if(self=="Domingo"){
            return "1"
        }
        return ""
    }
    

}

1.horas()
"Miercoles".dia


//Optional

let dias = ["GDL":120,"Pue":300,"MTY":100,"CDMX":200]
var existe:Int?

 existe = dias["CDMX"]
if let op = dias["Pue"]{
    
    print (op)
}
else{
    print("No existe")
}
    
    



    






